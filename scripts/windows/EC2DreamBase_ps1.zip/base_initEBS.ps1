# the following mount is not needed for Block Devices on EBS images 
#./mountebs.ps1 
# assumes the EBS is disk 2
diskpart.exe /s c:\admin\init_ebs.txt
# could not get FORMAT command to work in diskpart.exe
# so call the windows format. 
format.com E:/Q /FS:NTFS /V:<host>
  
