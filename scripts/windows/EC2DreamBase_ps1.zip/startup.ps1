#!/bin/bash
# setup host file 
./syncHost.ps1
# start service
#  net start "<service>"

