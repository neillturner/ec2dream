###       title:  lib-util.ps1
### description:  general purpose library
###      author:  Hal Rottenberg <hal@halr9000.com> (http://halr9000.com)
###     license:  CC-by 2.0 (http://creativecommons.org/licenses/by/2.0/)
###        date:  2008-08-22

function Get-WebFile {
### function: Get-WebFile
### version: 0.3
### "It's like wget, but not."
### Input: These options can be combined, parameter or pipeline is required
###   Paramater (1) (optional):
###      -  [string] URL of file you wish to get -or-
###      -  [system.uri] URL object of file you wish to get
###   Pipeline (optional):
###     Accepts pipelined [string] or [system.uri] objects
### Output:
###   Array of [System.IO.FileSystemInfo] objects (aka files)
### thanks to BS's fine code examples found here: http://bsonposh.com/modules/wordpress/?p=18

### TODO: 
###   - error checking, progress bar needs work
###   - what else should this do like wget?

  Param ( [system.uri]$srcUrl )

  Begin {
    $webClient = new-object System.Net.WebClient
    $process = @() # pipeline
    $objCollection = @() # output objects
  }

  Process {
    if ($_) { # anything in the pipeline?
      if ($_.AbsoluteUri) { # is it a string or a [system.uri] object?
        $process += $_.AbsoluteUri
      }
      else {
        $process += $_
      }
    }
  }

  End {
    if ($srcUrl) {$process += $srcUrl} # if URL was provided as parameter, add to pipeline
    $i = 1
    foreach ($Url in $process) {
      $tempFileName = [System.IO.Path]::GetTempFileName() # use temp file to store download
      if ([system.uri]$Url -eq $false) { throw "Unable to convert $Url to URL." }
      $localFileName = $tempFileName # + "." + $Url.Segments[$Url.Segments.Length-1]
      write-progress $Url "Total Progress ->" -percentcomplete ($i/$process.length*100)
      $result = $webClient.DownloadFile($Url,$localFileName) # downloads file
      $objFile = get-childitem $localFileName # gets reference to downloaded file 
      $objcollection += $objFile # add reference to output object
      $i++
    }
    Write-Output $objCollection # send down the pipeline
  }
}

function Copy-WebFile { 
### function: Copy-WebFile 
### This is the simpler file-oriented version of the object-oriented script above.
### The script takes two required parameters: URL and destination filename or path. 

### TODO: detect if dst is a file or a path and name file logically if not 
### specified

  Param (
    [system.uri]$srcUrl = $(throw "Specify the URL you wish to download."),
    $dstFile = $(throw "Specify a destination filename")
  )

  Begin {
    $tempFile = [System.IO.Path]::GetTempFileName()
    $webClient = new-object System.Net.WebClient
    $webClient.DownloadFile($srcUrl,$tempFile)
    move-item $tempfile $dstFile
  }
}

function Load-PsSnapin {
### function: Load-PsSnapin
### "A simple Snap-In picker script"
### from: http://www.nivot.org/2007/08/14/ASimpleSnapInPickerScript.aspx

  write-progress "Enumerating Snapins" "Registered..."
  $snaps = get-pssnapin -r
  write-progress "Enumerating Snapins" "Loaded..."
  $loaded = get-pssnapin | % {$_.name}
  $notloaded  = @()
  write-progress "Enumerating Snapins" "Complete." -Completed # glitchy
  $i = 0; "";
  foreach ($snap in $snaps) {
          if (-not($loaded -contains $snap.name)) {
                  Write-Host -fore cyan -nonewline "${i}) "
                  write-host -fore green $snap.name
                      $notloaded  += $snap
                  $i++
          }
  }
  if ($i -eq 0) {
          Write-Warning "Any eligible snapins are already loaded."
          exit;
  }
  $i--;
  Write-Host -fore yellow "<enter> to quit"
  do {
          write-host -nonewline "Load 0 - ${i}: ";
          $choice = [console]::readline()
          if ($choice -and ($choice -lt 0) -or ($choice -gt $i)) {
                  Write-Warning "'${choice}' is out of range!"
                  continue;
          }
          if ($choice) {
                  "loading $($notloaded[$choice].name) ..."
                  add-pssnapin $notloaded[$choice]
          }
  } while ($choice)
}


function Unzip-File
{
	param([string]$zipfilename, [string] $destination)
	
	if (-not (test-path "$env:ProgramFiles\7-Zip\7z.exe")) {throw "$env:ProgramFiles\7-Zip\7z.exe needed"}
	set-alias sz "$env:ProgramFiles\7-Zip\7z.exe"

	if(test-path($zipfilename))
	{
	        $outputOption = "-o$destination"
		Write-Output "Extracting files into $destination"
		write-host "output:" $outputOption
		sz x "$zipfilename" $outputOption -y
	}
}

