
   
  # IMPORTANT: Before running this script create a C:\admin folder and copy from your client machine 
  #  EC2DreamBase_win.zip (and unzip)
  #  private_key  file
  #  cert  file 
  #  settings.ps1 (after setting the values inside)
  # Relax the Execution Policy
  Set-ExecutionPolicy RemoteSigned
  . ./lib-util.ps1
  # helps in debugging
  Set-PSDebug -strict
  cd C:\admin
  # install EC2 API tools if desired
  #Copy-WebFile http://s3.amazonaws.com/ec2-downloads/ec2-api-tools.zip ec2-api-tools.zip
  #Unzip-File  ec2-api-tools.zip C:\admin
  # 
  # add anything extra here 
  
  
  
  