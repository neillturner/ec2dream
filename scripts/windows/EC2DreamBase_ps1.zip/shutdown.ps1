# net stop "<service>"
# umount ebs 
