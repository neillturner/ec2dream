# script to auto mount ebs at startup
# 
. ./settings.ps1
. ./lib-util.ps1

trap [Amazon.EC2.AmazonEC2Exception] {
  write-host
  write-error $("Error: " + $_.Exception.Message);
  exit
 }

function New-GenericList([type] $type)
{
  $base = [System.Collections.Generic.List``1]
  $qt = $base.MakeGenericType(@($type))
  New-Object $qt
}


Function error-message 
{
 Write-Host "*** Error calling EC2"
 [xml] $resxml = $res.ToXML()
 Format-XML $resxml
 exit
}
 
# namespace of amazon tools
$namespace = 'ns=http://ec2.amazonaws.com/doc/2009-07-15/'
# debug to make true enter any value, to make false set to empty 
$debug = ""
# switch between the next 2 lines to either use vol-id passed as user data or 
# a hard coded volume
$url_user_data = "http://169.254.169.254/latest/user-data"
$user_data = Get-WebFile $url_user_data
$ec2_vol = Get-Content $user_data 
$url_instance_id = 'http://169.254.169.254/latest/meta-data/instance-id'
$instance_id_file = Get-WebFile $url_instance_id
$instance_id = Get-Content $instance_id_file
# $ec2_vol = "vol-xxxxx"
if ($ec2_vol -eq $null) {
  Write-Host "*** No EBS specified"
} else {
 
  if ($Env:EC2_URL -eq $null -or $Env:EC2_URL.length -eq 0) {
     $ec2 = new-object Amazon.EC2.PowerEC2Dream($Env:AMAZON_ACCESS_KEY_ID,$Env:AMAZON_SECRET_ACCESS_KEY)
  } else {
     $ec2 = new-object Amazon.EC2.PowerEC2Dreamt($Env:AMAZON_ACCESS_KEY_ID,$Env:AMAZON_SECRET_ACCESS_KEY, $Env:EC2_URL)
  }
  Write-Host "*** Attaching volume $ec2_vol to instance $instance_id"
  $res = $ec2.AttachVolume($ec2_vol, $instance_id, "xvdf")
  $aws_attachment_status = $res["Status"]
  Write-Host "Status is $aws_attachment_status Sleep for 20 secs" 
  $max_sleep = 60
  $current_sleep = 0
  [array] $volume_array = $ec2_vol
  #while (!aws_attachment_status.Equals("attached")) and ($current_sleep<$max_sleep) {
    Start-Sleep -s 20
    $current_sleep = $current_sleep + 20 
    $res = $ec2.DescribeVolumes($volume_array)
    foreach ($r in $res) {
       $aws_attachment_status = $r["Status"]
    }
 #   Write-Host "Attach Status $aws_attachment_status Sleep for $current_sleep"
 #}   
} 