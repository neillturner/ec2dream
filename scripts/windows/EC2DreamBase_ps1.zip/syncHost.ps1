#
# fetch hosts from amazon EC2 meta-data
# Use the security group name as host name until tagging available
# Optional first parameter with hostname prefix
# write out a host file with physical IPs.
#
function New-GenericList([type] $type)
{
  $base = [System.Collections.Generic.List``1]
  $qt = $base.MakeGenericType(@($type))
  New-Object $qt
}
trap [Amazon.EC2.AmazonEC2Exception] {
  write-host
  write-error $("Error: " + $_.Exception.Message);
  exit
 }

Function help-message 
{
 Write-Host ""
  Write-Host "syncHosts: fetch hosts from amazon EC2 meta-data and update the Windows hosts file"
  Write-Host ""
  Write-Host "Usage: syncHost.ps1  [host-prefix]"
  Write-Host ""
  Write-Host "host-prefix:        prefix of hosts to match. Default is no prefix."
  Write-Host ""
 exit
}

. ./Settings.ps1

# namespace of amazon tools
$namespace = 'ns=http://ec2.amazonaws.com/doc/2009-07-15/'
# debug to make true enter any value, to make false set to empty 
$debug = ""
$hostPrefix = ""
$localhostnane = ""
# set if hostprefix if specified
if ($args[0] -ne $null) {
  if ($args[0].Equals("-h")) { help-message  }
  $hostPrefix = $args[0]
  Write-Host "Matching hosts with prefix $hostPrefix" 
}
Write-Host ""
$ip = ((ipconfig | findstr [0-9].\.)[0]).Split()[-1]
#
# find info about host 
#
$instance = ""
$image = ""
if ($Env:EC2_URL -eq $null -or $Env:EC2_URL.length -eq 0) {
   $ec2 = new-object Amazon.EC2.PowerEC2Dream($Env:AMAZON_ACCESS_KEY_ID,$Env:AMAZON_SECRET_ACCESS_KEY)
} else {
   $ec2 = new-object Amazon.EC2.PowerEC2Dream($Env:AMAZON_ACCESS_KEY_ID,$Env:AMAZON_SECRET_ACCESS_KEY, $Env:EC2_URL)
}
$res = $ec2.DescribeInstances()
Write-Host "Updating C:\WINDOWS\system32\drivers\etc\hosts"
Write-Host ""
Copy-Item "C:\WINDOWS\system32\drivers\etc\hosts" "C:\WINDOWS\system32\drivers\etc\hosts.bak"
"127.0.0.1  localhost"  | Out-File -filepath "C:\WINDOWS\system32\drivers\etc\hosts"

foreach ($r in $res)
{
  [array] $groupnames = $r["Groups"]
  $name = $groupnames[0]
  if ($hostPrefix.Length -gt 0) {
     if (!$name.StartsWith($hostPrefix)) { break } 
  }
  $state = $r["Name"]
  $dsn = $r["PrivateDnsName"]
  if ($state.Equals("running")) {
     $j =$dsn.IndexOf(".")
     $k = $dsn.IndexOf("-") 
     $dsn2 = $dsn.substring($k+1,$j-3)
     $dsna = $dsn2.Split("-")
     $dsn = $dsna[0]+"."+$dsna[1]+"."+$dsna[2]+"."+$dsna[3]
     Write-Host "$name $dsn"
     "$dsn $name" | Out-File -filepath "C:\WINDOWS\system32\drivers\etc\hosts"  -append
     if ($dsn.Equals($ip)) {
       $localhostnane = $name
     }  
  }
  # if we found this machine in the EC2 list create a script to set its local_hostname
  if ($localhostname.Length -gt 0) {
   $env_hostname = "$env:LOCAL_HOSTAME=`""+$localhostnane+"`"" 
   $env_hostname | out-File -filepath "D:\local_hostname.ps1"
  }
} 





