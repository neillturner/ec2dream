#
# EC2 Settings for shell powershell scripts
# add any extra settings here
#
$env:AMAZON_ACCESS_KEY_ID="<insert public key>"
$env:AMAZON_SECRET_ACCESS_KEY="<insert private key>"
$env:S3_PREFIX="<insert prefix i.e. company name>"
# uncomment the next 2 lines if in EU region
# $env:AWS_CALLING_FORMAT="SUBDOMAIN"
# $env:EC2_URL="https://eu-west-1.ec2.amazonaws.com/"
$env:EC2_PRIVATE_KEY="c:\xxxxxxxxxxxxxxxxxxxxx.pem"
$env:EC2_CERT="c:\yyyyyyyyyyyyyyyyyyyyyyyyyy.pem"
# the following not need for windows
# $env:EC2_HOME="<path-to-tools>"
# rem ***** Also add ;$env:EC2_HOME\bin to end of PATH variable *****
# $env:path += ";<path-to-tools>\bin"
# location of EC2 .NET and EC2 S3 
[System.Reflection.Assembly]::LoadFrom("$pwd\Amazon.EC2.dll")
[System.Reflection.Assembly]::LoadFrom("$pwd\Affirma.ThreeSharp.dll")
[System.Reflection.Assembly]::LoadFrom("$pwd\Affirma.ThreeSharp.Wrapper.dll")

